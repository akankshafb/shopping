const setLocalStorageData=(data)=>{
    debugger;
    return {type:"SET_LOCALSTORAGE",payload:data};
}

export default setLocalStorageData;