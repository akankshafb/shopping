const addToCart=(data)=>{
    debugger;
     return {type:"ADD_TO_CART",payload:data};
 }
 export default addToCart;